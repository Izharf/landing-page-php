<?php
/*
Plugin Name: Auto Post Fetcher
Description: Fetches content from URLs and creates WordPress posts with dynamically generated Forminator Forms.
Version: 2.0
Author: Creatives
*/

if (!defined('ABSPATH')) exit;

// Load required files
require_once plugin_dir_path(__FILE__) . 'includes/form-creator.php';
require_once plugin_dir_path(__FILE__) . 'includes/post-fetcher.php';
require_once plugin_dir_path(__FILE__) . 'includes/admin-page.php';

// Load WordPress media functions
require_once(ABSPATH . 'wp-admin/includes/media.php');
require_once(ABSPATH . 'wp-admin/includes/file.php');
require_once(ABSPATH . 'wp-admin/includes/image.php');